<!--<footer class="page-footer white">-->
<!--    <div class="container">-->
<!--        <div class="row m0 p-40">-->
<!--            <div class="col l9 s12 left-align"><a href="www.fownders.com"><img src="http://www.fownders.co/hubfs/Fownders%20Logos/fownders-logo-transparant.png" alt="fownders-facebook" width="160" height="35" align="center"></a>-->
<!--                <ul>-->
<!--                    <li><a class="brand-text text-upper color-hover left-align hover-grey-text" href="http://www.fownders.co/hubfs/Fownders%20Docs/Privacy%20Policy-%20Fownders.pdf" target="_blank">Privacy Policy</a></li>-->
<!--                    <li><a class="brand-text text-upper color-hover left-align hover-grey-text" href="http://www.fownders.com/about/" target="_blank">About Us</a></li>-->
<!--                    <li><a class="brand-text text-upper color-hover left-align hover-grey-text" href="mailto:support@fownders.com">Contact</a></li>-->
<!--                </ul>-->
<!--            </div>-->
<!--            <div class="col l2 offset-l1 s12 left-align">-->
<!--                <ul class="mobile-icons">-->
<!--                    <li class="footer-icons-margin"><a class="grey-text text-lighten-3" href="https://www.facebook.com/fowndersnewark/"><img class="white-hover" src="http://www.fownders.co/hubfs/Social-Icons/FacebookIcon.png" alt="fownders-facebook" width="32px"></a></li>-->
<!--                    <li class="footer-icons-margin"><a class="grey-text text-lighten-3" href="https://www.instagram.com/fownders/?hl=en"><img class="white-hover" src="http://www.fownders.co/hubfs/Social-Icons/InstagramIcon.png" alt="fownders-ig" width="32px" height="32px"></a></li>-->
<!--                    <li class="footer-icons-margin"><a class="grey-text text-lighten-3" href="https://twitter.com/Fownders?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor" alt="fownders-twitter"><img class="white-hover" src="http://www.fownders.co/hubfs/Social-Icons/TwitterIcon.png" alt="fownders-ig" width="32px"></a></li>-->
<!--                    <li class="footer-icons-margin"><a class="grey-text text-lighten-3" href="https://www.linkedin.com/company-beta/10592196/"><img class="white-hover" src="http://www.fownders.co/hubfs/Social-Icons/LinkedinIcon.png" alt="fownders-linkedin" width="32px"></a></li>-->
<!--                </ul>-->
<!--            </div>-->
<!--        </div>-->
<!--    </div>-->
<!--    <hr>-->
<!--    <div class="footer-copyright">-->
<!--        <div class="container">-->
<!--            <div class="row m0">-->
<!--                <div class="col s12 left-align mobile-center">-->
<!--                    <p class="black-text left-align f-12 mobile-small">© 2017 COPYRIGHT | FOWNDERS | ALL RIGHTS RESERVED <br class="show-on-small-only"><br class="show-on-small-only"><br class="show-on-small-only"><br class="show-on-small-only"></p>-->
<!--                </div>-->
<!--            </div>-->
<!--        </div>-->
<!--    </div>-->
<!--</footer>-->
<script src='http://cdn.jsdelivr.net/npm/vivus@latest/dist/vivus.min.js'></script>
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='http://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.2/raphael-min.js'></script>
<!--<script>-->
<!--    new Vivus('my-svg', {duration: 200}, myCallback);-->
<!--</script>-->